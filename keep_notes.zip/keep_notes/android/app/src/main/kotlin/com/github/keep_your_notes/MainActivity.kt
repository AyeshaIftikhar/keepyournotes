package com.github.keep_your_notes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
